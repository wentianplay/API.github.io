function onDrawerListItemClick(data, recyclerView, listIndex, itemIndex)

    local listData = data.get(listIndex);

    local itemData = listData.get(itemIndex);

    local itemTitle = itemData.getTitle();

    
end

function onSearchEvent(keyword)

    
end

function onMenuItemClick(title)


end


function onFloatingActionButtonClick(v)


end